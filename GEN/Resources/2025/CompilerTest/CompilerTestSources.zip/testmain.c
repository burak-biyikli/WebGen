// This file is a simple microbenchmark for vectorization done by compilers

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct {
    int f0;
    int f1;
    int f2;
    int f3;
    int f4;
    int f5;
    int f6;
} fields;

//Forces the overhead of the loop to be known, even if the function is inlined
volatile int force = 0;

int TrueEmpty( fields *A, fields *B, int length ){
	int sum = 0;
	return force + sum;
}

int BasicEmpty( fields *A, fields *B, int length ){
	int sum = 0;
	for(int ii = 0; ii<length; ii++){
		sum += 0;
	}
	return force + sum;
}

int UnalignedSum( fields *A, fields *B, int length){
	int sum = 0;
	for(int ii = 0; ii<length; ii++){
		sum += (A+ii)->f1 + (B+ii)->f1;
	}
	return force + sum;
}

int FullSum(fields *A, fields *B, int length){
	int sum = 0;
	for(int ii = 0; ii<length; ii++){
		sum += (A+ii)->f1 + (B+ii)->f1;
		sum += (A+ii)->f2 + (B+ii)->f2;
		sum += (A+ii)->f3 + (B+ii)->f3;
		sum += (A+ii)->f4 + (B+ii)->f4;
		sum += (A+ii)->f5 + (B+ii)->f5;
		sum += (A+ii)->f6 + (B+ii)->f6;
		sum += (A+ii)->f0 + (B+ii)->f0;
	}
	return force + sum;
}

int main(int argc, char *argv[]){
	if(argc < 4){
		printf("Useage: a.out <Test no> <Data Len> <data>\n");
		return -1;
	}
	
	int t = atoi(argv[1]);
	int c = atoi(argv[2]);
	int l = c / (sizeof(fields) * 2);
	fields *A = (fields *)(&argv[3]);
	fields *B = (fields *)(&argv[3]);
	B = B + l;
	
	printf("%s:\tRunning case %d with length %d (%d)\n", argv[0], t, l, c);
	
	switch (t){
		case 0 : for(int jj=0; jj<100000; jj++){ c += TrueEmpty(A, B, l);    } break;
		case 1 : for(int jj=0; jj<100000; jj++){ c += BasicEmpty(A, B, l);   } break;
		case 2 : for(int jj=0; jj<100000; jj++){ c += UnalignedSum(A, B, l); } break;
		case 3 : for(int jj=0; jj<100000; jj++){ c += FullSum(A, B, l);      } break;
		default: c += 4; break;
	}

	return c;
}
