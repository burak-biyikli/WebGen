#!/usr/bin/bash

mlen=$(getconf ARG_MAX)

svar=$(cat testdata_100k.txt)
slen=${#svar}

ff="-Wall -Werror"
ac="-S -masm=intel -Wall -Werror"

tc="${1:?Error: Missing required argument.}"
echo "Script is running with test case: $tc"

echo "Running with ${slen} out of ${mlen}"
echo "++++====++++====++++====++++====++++====++++===="
echo ""

gcc-11 ${ff} testmain.c -O0 -o gcc-11_base.run
gcc-11 ${ff} testmain.c -Os -o gcc-11_Osize.run
gcc-11 ${ff} testmain.c -O3 -o gcc-11_O3.run
gcc-11 ${ff} testmain.c -Ofast -o gcc-11_Ofast.run
gcc-11 ${ff} testmain.c -O3 -march=znver3 -o gcc-11_Oarch.run

gcc-12 ${ff} testmain.c -O0 -o gcc-12_base.run
gcc-12 ${ff} testmain.c -Os -o gcc-12_Osize.run
gcc-12 ${ff} testmain.c -O3 -o gcc-12_O3.run
gcc-12 ${ff} testmain.c -Ofast -o gcc-12_Ofast.run
gcc-12 ${ff} testmain.c -O3 -march=znver3 -o gcc-12_Oarch.run

clang-14 ${ff} testmain.c -O0 -o clang-14_base.run
clang-14 ${ff} testmain.c -Os -o clang-14_Osize.run
clang-14 ${ff} testmain.c -O3 -o clang-14_O3.run
clang-14 ${ff} testmain.c -Ofast -o clang-14_Ofast.run
clang-14 ${ff} testmain.c -O3 -march=znver3 -o clang-14_Oarch.run

time for i in {1..10}; do ./gcc-11_base.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-11_Osize.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-11_O3.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-11_Ofast.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-11_Oarch.run ${tc} ${slen} ${svar}; done

time for i in {1..10}; do ./gcc-12_base.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-12_Osize.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-12_O3.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-12_Ofast.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./gcc-12_Oarch.run ${tc} ${slen} ${svar}; done

time for i in {1..10}; do ./clang-14_base.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./clang-14_Osize.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./clang-14_O3.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./clang-14_Ofast.run ${tc} ${slen} ${svar}; done
time for i in {1..10}; do ./clang-14_Oarch.run ${tc} ${slen} ${svar}; done

gcc-11 ${ac} testmain.c -O0 -o gcc-11_base.asm
gcc-11 ${ac} testmain.c -Os -o gcc-11_Osize.asm
gcc-11 ${ac} testmain.c -O3 -o gcc-11_O3.asm
gcc-11 ${ac} testmain.c -Ofast -o gcc-11_Ofast.asm
gcc-11 ${ac} testmain.c -O3 -march=znver3 -o gcc-11_Oarch.asm

gcc-12 ${ac} testmain.c -O0 -o gcc-12_base.asm
gcc-12 ${ac} testmain.c -Os -o gcc-12_Osize.asm
gcc-12 ${ac} testmain.c -O3 -o gcc-12_O3.asm
gcc-12 ${ac} testmain.c -Ofast -o gcc-12_Ofast.asm
gcc-12 ${ac} testmain.c -O3 -march=znver3 -o gcc-12_Oarch.asm

clang-14 ${ac} testmain.c -O0 -o clang-14_base.asm
clang-14 ${ac} testmain.c -Os -o clang-14_Osize.asm
clang-14 ${ac} testmain.c -O3 -o clang-14_O3.asm
clang-14 ${ac} testmain.c -Ofast -o clang-14_Ofast.asm
clang-14 ${ac} testmain.c -O3 -march=znver3 -o clang-14_Oarch.asm


