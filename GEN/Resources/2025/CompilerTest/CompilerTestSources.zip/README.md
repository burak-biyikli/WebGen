Created by Burak Biyikli

You have my blessing to do whatever with these files as long as you don't blame me for the results.

Good luck and have fun!

Graphs avalible at 

https://docs.google.com/spreadsheets/d/1xnCOkD6X1nFe3tvv1R5mvzaFBLsgkR7_kGljoelqAPk/edit?usp=sharing
